ELMINYAWE Relay
================
Windows: extract the entire ZIP, then double-click start-elminyawe-relay.cmd.
Keep the window open while using the toolkit. Close it when finished.
The CMD starts elminyawe-relay.ps1 using Windows PowerShell; Python is not required for this method.
Alternative: python elminyawe-relay.py (Python 3). Do not run both versions together.
Health: http://127.0.0.1:43210/health
Service name: elminyawe-relay
The toolkit wire format is unchanged, including X-Orion-Relay: 1.
For local use only. Do not expose on a public interface or forward the port.
Based on Orion Relay; see NOTICE.txt and LICENSE.
This rebranded package has not been tested on Windows here.
