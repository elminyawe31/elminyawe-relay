@echo off
title ELMINYAWE Relay
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0elminyawe-relay.ps1"
pause
